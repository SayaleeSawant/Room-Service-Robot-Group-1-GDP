import cv2
import pytesseract
import numpy as np

def getcontours(img1, imgcpy):
	
	contours, hierarchy = cv2.findContours(img1, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
	area = []
	for cnt in contours:
		areas = cv2.contourArea(cnt)
		area.append(areas)
		Sort_area = sorted(contours, key = cv2.contourArea, reverse = True) #largest
		

			
			

	return imgcpy
	
			

			


def ocr(edges, img1):
	pytesseract.pytesseract.tesseract_cmd = r'c:\program files\tesseract-ocr\tesseract.exe'
	himg, wimg, _ = img1.shape #size of image

	#to detect only digit
	#add configuration to extract character #please refer documentation for more details of oem and psm
	conf = r'--oem 3 --psm 6 outputbase digits'
	boxes = pytesseract.image_to_data(edges, config= conf) #output in the string #boxes = [level pageno blockno paragraphno lineno wordno left topwidth height config text]
	#print(pytesseract.image_to_string(img_binary))
	
	for x,b in enumerate(boxes.splitlines()): #to set the counter used 'enumarate' command
		if x!=0: #1st row is heading to avoid the titles used conditional statement
			b = b.split()
			
			if len(b)==12: #to select specific data used conditional statement
				x,y,w,h = int(b[6]), int(b[7]), int(b[8]), int(b[9])
				cv2.rectangle(img1, (x,y),(x+w,y+h),(0,0,255),1)
				cv2.putText(img1, b[11],(x,y), cv2.FONT_HERSHEY_COMPLEX, 1, (255,0,0), 2)
				b1 = (b[11])
				print(b1)
				if b1=="3034" or b1=="3036":
					print(b1)
					break





cap = cv2.VideoCapture(0)

while True:
	_,img = cap.read()
	imgcopy = img.copy()
	#image preprocessing
	img_grayscale = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	(thresh, img_binary) = cv2.threshold(img_grayscale, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
	edges = cv2.Canny(img_grayscale,100,200)

	img1 = getcontours(edges, imgcopy)
	ocr(edges,imgcopy)

	cv2.imshow('Result1', img)
	cv2.imshow('Result1', imgcopy)
	cv2.imshow('Result1', img1)

	cv2.waitKey(1)

