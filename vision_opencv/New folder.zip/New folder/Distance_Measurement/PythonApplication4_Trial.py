import imutils
import cv2
from imutils import paths
import numpy as np
import os

def find_marker(img):
	
    parameters = cv2.aruco.DetectorParameters_create()
    aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_50)
    corners, ids, _ = cv2.aruco.detectMarkers(img, aruco_dict, parameters=parameters)
    #print(corners)
    int_corners = np.int0(corners)
    #print(int_corners)
    cv2.polylines(img, int_corners, True, (0, 255, 0), 5)
    # Aruco Perimeter
    if ids is not None:
        aruco_perimeter = cv2.arcLength(corners[0], True)
        #print(aruco_perimeter)
        w = aruco_perimeter/4
        #print(w)
        # peri = 974.649/4 = 243.66
    
        # Find Focal length
        #w = 243.66
        W = 8.5
        #d = 30
        #f = (w*d)/W
        #print(f)
    

        #Finding Distance
        f = 859.9764705882353
        d = (W*f)/w

        #print(d)
        cv2.putText(img, f'Length: {int(d)}cm', (100,100), cv2.FONT_HERSHEY_SIMPLEX, 1, color = (255,0,0), thickness = 2)






cap = cv2.VideoCapture(0)
while True:
    success, img = cap.read()
    find_marker(img)
    cv2.imshow('img',img)
    k = cv2.waitKey(30) & 0xff
    if k == 27:
        break
cap.release()
cv2.destroyAllWindows()
