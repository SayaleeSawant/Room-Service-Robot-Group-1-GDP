from imutils import paths
import numpy as np
import imutils
import cv2

def find_marker(image):
	# convert the image to grayscale, blur it, and detect edges
	gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
	gray = cv2.GaussianBlur(gray, (5, 5), 0)
	edged = cv2.Canny(gray, 35, 125)
	# find the contours in the edged image and keep the largest one;
	# we'll assume that this is our piece of paper in the image
	cnts = cv2.findContours(edged.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
	cnts = imutils.grab_contours(cnts)
	print(cnts)
	c = max(cnts, key = cv2.contourArea)
	# compute the bounding box of the of the paper region and return it

	    #gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    #key = getattr(aruco, f'DICT_{markerSize}X{markerSize}_{totalMarkers}')

	dictionary = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_50)  
	markerImage = np.zeros((200, 200), dtype=np.uint8)
	markerImage = cv2.aruco.drawMarker(dictionary, 33, 200, markerImage, 1);
	dictionary = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_50)
	parameters =  cv2.aruco.DetectorParameters_create()
	markerCorners, markerIds, rejectedCandidates = cv2.aruco.detectMarkers(img, dictionary, parameters=parameters)
	



	return cv2.minAreaRect(c)